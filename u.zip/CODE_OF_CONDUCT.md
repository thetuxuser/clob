# Code of Conduct

## Our Pledge

We as contributors and maintainers of clob pledge to make participation in our project and community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, caste, color, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

---

## Our Standards

**Examples of behavior that contributes to a positive environment:**

- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community
- Showing empathy towards other community members
- Giving credit where credit is due

**Examples of unacceptable behavior:**

- The use of sexualized language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information, such as physical or email addresses, without explicit permission
- Dismissing or belittling contributions from less experienced members
- Sustained disruption of discussions
- Other conduct which could reasonably be considered inappropriate in a professional setting

---

## Our Responsibilities

Project maintainers are responsible for clarifying and enforcing our standards of acceptable behavior and will take appropriate and fair corrective action in response to any behavior that they deem inappropriate, threatening, offensive, or harmful.

Project maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct, and will communicate reasons for moderation decisions when appropriate.

---

## Scope

This Code of Conduct applies within all community spaces — GitHub issues, pull requests, discussions, Discord (if applicable), and any other official clob channels — and also applies when an individual is officially representing the project in public spaces.

---

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the project maintainers at:

- **GitHub:** Open a private [Security Advisory](https://github.com/crishacks/clob/security/advisories/new) (they support private messages)
- **Email:** conduct@crishacks.dev *(replace with actual contact)*

All complaints will be reviewed and investigated promptly and fairly.

All project maintainers are obligated to respect the privacy and security of the reporter of any incident.

---

## Enforcement Guidelines

Maintainers will follow these Community Impact Guidelines in determining consequences:

### 1. Correction

**Impact:** Minor inappropriate language or behavior.

**Consequence:** Private written warning with clarity on why the behavior was inappropriate. A public apology may be requested.

### 2. Warning

**Impact:** A violation through a single incident or series of actions.

**Consequence:** A warning with consequences for continued behavior. No interaction with the involved parties for a specified period. Violating these terms may lead to a temporary or permanent ban.

### 3. Temporary Ban

**Impact:** A serious violation of community standards.

**Consequence:** A temporary ban from any public interaction or communication with the community for a specified period.

### 4. Permanent Ban

**Impact:** Demonstrating a pattern of violation of community standards, harassment, or aggression toward individuals.

**Consequence:** A permanent ban from any public interaction within the community.

---

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.

For answers to common questions about this code of conduct, see the [FAQ](https://www.contributor-covenant.org/faq). Translations are available at [contributor-covenant.org/translations](https://www.contributor-covenant.org/translations).
